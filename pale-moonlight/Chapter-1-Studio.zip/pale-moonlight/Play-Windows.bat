@echo off
setlocal
set "MOONLIGHT_SCUMMVM=%ProgramFiles%\ScummVM\scummvm.exe"
if exist "%MOONLIGHT_SCUMMVM%" goto run
set "MOONLIGHT_SCUMMVM=%ProgramFiles(x86)%\ScummVM\scummvm.exe"
if exist "%MOONLIGHT_SCUMMVM%" goto run
echo Install ScummVM from https://www.scummvm.org/downloads/
echo Then choose Add Game and select this project's game folder.
pause
exit /b 1
:run
"%MOONLIGHT_SCUMMVM%" --path="%~dp0game" sludge:sludge
